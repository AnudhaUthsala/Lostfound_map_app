package com.example.lostfound;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Create extends AppCompatActivity {

    private RadioButton lost, found;
    private EditText nameEditText, contactEditText, descriptionEditText, locationEditText;
    private TextView dateEditText;
    private Button saveButton, map;
    private Calendar calendar;
    public static String address = "";
    private int position = -1;
    private OrmliteHelper ormliteHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        calendar = Calendar.getInstance();

        nameEditText = findViewById(R.id.name);
        contactEditText = findViewById(R.id.contact);
        descriptionEditText = findViewById(R.id.description);
        dateEditText = findViewById(R.id.date);
        locationEditText = findViewById(R.id.location);
        saveButton = findViewById(R.id.save);
        lost = findViewById(R.id.lost);
        found = findViewById(R.id.found);
        map = findViewById(R.id.loc);
        ormliteHelper = new OrmliteHelper(Create.this);

        dateEditText.setOnClickListener(view -> showDatePicker());
        lost.setOnClickListener(view -> updatePosition(0));
        found.setOnClickListener(view -> updatePosition(1));

        map.setOnClickListener(view -> openMapFragment());

        saveButton.setOnClickListener(view -> {
            try {
                savePost();
            } catch (InterruptedException | SQLException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private void showDatePicker() {
        new DatePickerDialog(this, dateSetListener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private DatePickerDialog.OnDateSetListener dateSetListener = (view, year, monthOfYear, dayOfMonth) -> {
        calendar.set(year, monthOfYear, dayOfMonth);
        updateDateEditText();
    };

    private void updateDateEditText() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        dateEditText.setText(sdf.format(calendar.getTime()));
    }

    private void updatePosition(int newPosition) {
        position = newPosition;
        lost.setChecked(position == 0);
        found.setChecked(position == 1);
    }

    private void openMapFragment() {
        MapsFragment firstFragment = new MapsFragment();
        firstFragment.setArguments(getIntent().getExtras());
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, firstFragment)
                .addToBackStack(null)
                .commit();
    }

    private void savePost() throws InterruptedException, SQLException {
        // Perform validation
        Toast.makeText(this,"Mapping Location & Save",Toast.LENGTH_LONG).show();

        String[] parts;
        String location = locationEditText.getText().toString();
        if (location.contains("\n")) {
            parts = locationEditText.getText().toString().split("\n");
        } else {
            parts = new String[]{location};
        }

// Now parts[0] will contain the text from locationEditText and parts[1] will contain the text from address if "\n" was present, otherwise, parts will contain only one element with the input string.
        String locationText = parts[0];
        locationEditText.setText(locationText + "\n" + address);
        Thread.sleep(3000);
        if (nameEditText.getText().toString().isEmpty() || contactEditText.getText().toString().isEmpty() ||
                descriptionEditText.getText().toString().isEmpty() || dateEditText.getText().toString().isEmpty() ||
                locationEditText.getText().toString().isEmpty() || position == -1) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        PostDTO postDTO = new PostDTO();
        if(position == 0 ){
            postDTO.setLost(true);
        }
        else if(position == 1 ){
            postDTO.setLost(false);
        }
        postDTO.setDate(dateEditText.getText().toString());
        postDTO.setContact(contactEditText.getText().toString());
        postDTO.setDescription(descriptionEditText.getText().toString());
        postDTO.setLocation(locationEditText.getText().toString());
        postDTO.setName(nameEditText.getText().toString());

        ormliteHelper.createOrUpdate(postDTO);

        // Here, integrate your database logic
        Toast.makeText(this, "Post Successfully Added", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, View.class);
        startActivity(intent);
    }
}
