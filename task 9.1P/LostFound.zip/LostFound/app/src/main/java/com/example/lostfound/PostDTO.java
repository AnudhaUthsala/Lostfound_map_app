package com.example.lostfound;

import com.j256.ormlite.field.DatabaseField;

public class PostDTO {
    @DatabaseField(generatedId = true)
    private int id;

    @DatabaseField
    private String postType;

    @DatabaseField
    private String name;

    @DatabaseField
    private String contact;

    @DatabaseField
    private String description;

    @DatabaseField
    private String date;

    @DatabaseField
    private String location;

    @DatabaseField
    private boolean isLost;

    public PostDTO() {
        // Empty constructor needed by ORM
    }

    public PostDTO(String postType, String name, String contact, String description, String date, String location, boolean isLost) {
        this.postType = postType;
        this.name = name;
        this.contact = contact;
        this.description = description;
        this.date = date;
        this.location = location;
        this.isLost = isLost;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPostType() {
        return postType;
    }
    public boolean isLost() {
        return isLost;
    }

    public void setLost(boolean lost) {
        isLost = lost;
    }
    public void setPostType(String postType) {
        this.postType = postType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
