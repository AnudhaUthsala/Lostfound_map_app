package com.example.lostfound;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    public static PostsAdapter postsAdapter;
    private OrmliteHelper ormliteHelper;
    public static List<PostDTO> postlist = new ArrayList<>();
    private ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ormliteHelper  = new OrmliteHelper(this);
        imageView      = findViewById(R.id.imageView4);
        boolean isLost = getIntent().getBooleanExtra("isLost", true);

        recyclerView = findViewById(R.id.postlist);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CreateOrView.class);;
                startActivity(intent);
            }
        });

        try {
            postlist = ormliteHelper.getDataByField(PostDTO.class, "isLost", isLost);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        postsAdapter = new PostsAdapter(this,postlist);
        recyclerView.setAdapter(postsAdapter);
        postsAdapter.notifyDataSetChanged();

    }

}