package com.example.lostfound;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lostfound.PostDTO;
import com.example.lostfound.R;

import java.sql.SQLException;
import java.util.List;

public class PostsAdapter extends RecyclerView.Adapter<PostsAdapter.ItemViewHolder> {

    private Context context;
    private List<PostDTO> postlist;
    private OrmliteHelper ormliteHelper;

    public PostsAdapter(Context context, List<PostDTO> postlist) {
        this.context = context;
        this.postlist = postlist;
    }

    @NonNull
    @Override
    public PostsAdapter.ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostsAdapter.ItemViewHolder holder, int position) {
        PostDTO postDTO = postlist.get(position);
        if(!postDTO.isLost()){
            holder.title.setText("Found");
        }
        holder.description.setText(postDTO.getDescription());
        holder.date.setText(postDTO.getDate());
        holder.location.setText(postDTO.getLocation());
        holder.contact.setText(postDTO.getContact());

        holder.deleteIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setMessage("Are you sure you want to delete this Post?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                ormliteHelper = new OrmliteHelper(context);
                                try {
                                    ormliteHelper.deleteById(PostDTO.class , postlist.get(position).getId());
                                } catch (SQLException e) {
                                    throw new RuntimeException(e);
                                }
                                RefreshItems(postDTO.isLost());
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // User clicked No button, do nothing
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });
    }
    private void RefreshItems(boolean isLost) {
        try {
            MainActivity.postlist.clear(); // Clear the existing list
            postlist = ormliteHelper.getDataByField(PostDTO.class, "isLost", isLost);// Add all items from the database
            notifyDataSetChanged(); // Notify adapter that data has changed
        } catch (SQLException e) {
            Toast.makeText(context, "Can not Load Data", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return postlist.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {

        private TextView title;
        private TextView description,date,location,contact;
        private ImageView deleteIcon;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.lof);
            description = itemView.findViewById(R.id.des);
            deleteIcon = itemView.findViewById(R.id.delete);
            date = itemView.findViewById(R.id.date);
            location = itemView.findViewById(R.id.location);
            contact = itemView.findViewById(R.id.number);
        }
    }
}
