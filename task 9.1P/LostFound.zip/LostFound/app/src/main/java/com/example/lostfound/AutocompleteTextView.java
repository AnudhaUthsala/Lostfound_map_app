package com.example.lostfound;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;

import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;

import java.util.ArrayList;
import java.util.List;

public class AutocompleteTextView extends ArrayAdapter<String> implements Filterable {
    private List<String> results;
    private PlacesClient placesClient;

    public AutocompleteTextView(Context context, int resource) {
        super(context, resource);
        Places.initialize(context, "AIzaSyCD8uy347uj0va-xBAr9VsLTsmW4KY6vfA");
        placesClient = Places.createClient(context);
        results = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return results.size();
    }

    @Override
    public String getItem(int position) {
        return results.get(position);
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults filterResults = new FilterResults();
                if (constraint != null) {
                    List<String> placesSuggestions = getPlacesAutocomplete(constraint);
                    filterResults.values = placesSuggestions;
                    filterResults.count = placesSuggestions.size();
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                if (results != null && results.count > 0) {
                    notifyDataSetChanged();
                } else {
                    notifyDataSetInvalidated();
                }
            }
        };
    }

    private List<String> getPlacesAutocomplete(CharSequence constraint) {
        final List<String> resultList = new ArrayList<>();
        AutocompleteSessionToken token = AutocompleteSessionToken.newInstance();
        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setSessionToken(token)
                .setQuery(constraint.toString())
                .build();

        placesClient.findAutocompletePredictions(request).addOnSuccessListener((response) -> {
            for (AutocompletePrediction prediction : response.getAutocompletePredictions()) {
                resultList.add(prediction.getPrimaryText(null).toString());
            }
            notifyDataSetChanged(); // Notify adapter after getting results
        }).addOnFailureListener((exception) -> {
            exception.printStackTrace();
        });

        return resultList;
    }
}
