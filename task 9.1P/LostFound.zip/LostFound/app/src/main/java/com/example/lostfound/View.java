package com.example.lostfound;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

public class View extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        // Initialize views
        LinearLayout lostListLayout = findViewById(R.id.lost_list);
        LinearLayout foundListLayout = findViewById(R.id.found_list);

        ImageView imageView = findViewById(R.id.imageView2);

        // Load the GIF with Glide
        Glide.with(this)
                .load(R.drawable.post)
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.RESOURCE)) // Cache the GIF resource
                .into(imageView);

        lostListLayout.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                navigateToAnotherActivity(MainActivity.class, true);
            }
        });
        foundListLayout.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                navigateToAnotherActivity(MainActivity.class, false);
            }
        });

    }
    private void navigateToAnotherActivity(Class<?> destinationActivity, boolean isLost) {
        Intent intent = new Intent(this, destinationActivity);
        intent.putExtra("isLost", isLost);
        startActivity(intent);
    }

}